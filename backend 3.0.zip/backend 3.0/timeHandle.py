import pandas as pd

def timeHandler():
    df=pd.read_csv('myDataSet.csv')
    df['Date_Time'] = pd.to_datetime(df['Date_Time'])
    # print(df['Date_Time'])
    df['hour'] = df.Date_Time.dt.hour
    result_df = df.groupby(['hour']).mean().reset_index()
    result_df=result_df.sort_values('Date_Time')
    # print((result_df["hour"]).count())
    final_df=result_df["Discharge_Capacity(Ah)"].round(2)
    final_df=100-(final_df/1.8)*100
    final_df=final_df.head(6).tolist() 
    final_df_hour=result_df["hour"].head(6).tolist()    
    return {
        "graphData": final_df,
        "hourData":final_df_hour
    }
