from flask import Flask,request
from sklearn.ensemble import RandomForestRegressor
import numpy as np
import math
from flask_cors import CORS
import joblib
from model import measureErrorHelper
from timeHandle import timeHandler
app=Flask(__name__)
# CORS(app)
class Battery:
    def __init__(self,voltage,current):
        self.voltage=voltage
        self.current=current
        

class RandomForestModel:
    def __init__(self):
        self.model=RandomForestRegressor()
    
    def loadModel(self,modelPath):
        self.model=joblib.load(modelPath)

    def predict(self,batteryData):
        X=np.array([batteryData.voltage, batteryData.current]).reshape(1,-1)
        return self.model.predict(X)

class HealthPrediction:
    def __init__(self,battery,model):
        self.battery=battery
        self.model=model
        result=self.model.predict(self.battery)
        self.healthState=round(100-((result[0]/1.8)*100))

@app.route('/predict',methods=['POST'])
def getPrediction():
    data=request.get_json()
    battery=Battery(data['voltage'], data['current'])

    model=RandomForestModel()
    model.loadModel('model.pkl')
    prediction=HealthPrediction(battery,model)

    return {'healthState': prediction.healthState}

@app.route('/error',methods=['GET','POST'])
def measureError():
    return measureErrorHelper()

@app.route('/graph',methods=['GET'])
def graphData():
    return timeHandler()
if __name__=="__main__":
    app.run(debug=True)
