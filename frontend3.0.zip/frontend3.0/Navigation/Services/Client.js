import axios from 'axios';

export async function Client(reqmethod,requestBody,endpoint){
    let url=`http://192.168.219.185:5000/predict`
    let requestConfig={
        method:"POST",
        url:url,
        data:requestBody,
        headers:{
            "Content-Type":'application/json',
            "Access-Control-Allow-Origin":"*"
        }
    }
    let response=await axios(requestConfig)
    return response
}