import { Client } from "./Client";

export const GetBatteryData=async (requestBody) =>{
    let response=await Client("POST",requestBody,"predict")
    return response.data
}