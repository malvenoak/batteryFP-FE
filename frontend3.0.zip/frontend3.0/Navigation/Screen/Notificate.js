import React, { useState, useEffect } from 'react';
import { FlatList,SafeAreaView, Text, View } from 'react-native';
import { SwipeListView } from 'react-native-swipe-list-view';
import * as Notifications from 'expo-notifications';

const Notificate = () => {
  const [notifications, setNotifications] = useState([]);

  const askForNotificationPermission = async () => {
    const { status } = await Notifications.requestPermissionsAsync();
    if (status !== 'granted') {
      alert('Permission to show notifications was denied!');
    }
  };

  useEffect(() => {
    askForNotificationPermission();
    fetchNotifications();
  }, []);

  const fetchNotifications = () => {
    // Fetch notifications data (dummy data for example)
    const dummyNotifications = [
      { id: '1', title: 'ALERT', body: 'Battery is in dangerous condition. ' },
      
    ];
    setNotifications(dummyNotifications);
  };

  const renderNotification = ({ item }) => (
    <View style={{ padding: 13, borderBottomWidth: 1, borderBottomColor: '#ccc' }}>
      <Text>{item.title}</Text>
      <Text>{item.body}</Text>
    </View>
  );

  return (
    <SafeAreaView style={{ flex: 0}}>
    <SwipeListView
    style={{backgroundColor:"#dddddd"}}
      data={notifications}
      renderItem={renderNotification}
      keyExtractor={item => item.id}
      disableRightSwipe={true}
      rightOpenValue={-75} // Swipe length for dismissal
      renderHiddenItem={() => (
        <View style={{ flex: 1, alignItems: 'flex-end', justifyContent: 'center', paddingRight: 20 }}>
          {/* <Text style={{ color: '#fff', backgroundColor: 'red', padding: 10 }}>Delete</Text> */}
        </View>
      )}
      onSwipeValueChange={({ key, value }) => {
        if (value <= -75) {
          // Handle delete action
          const updatedNotifications = notifications.filter(item => item.id !== key);
          setNotifications(updatedNotifications);
        }
      }}
    />
    </SafeAreaView>
  );
};

export default Notificate;
