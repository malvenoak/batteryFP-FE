import { View } from 'react-native';
import React, { useEffect, useState } from 'react';
import { LineChart } from 'react-native-chart-kit';

export const MonthlyChargeTimeGraph = (props) =>{
  // console.log((props.data2),"hello")
  const [grahDetail,setGraphDetails]=useState([100,22,22,22,22,22])
  useEffect(()=>{
    const newList=[]
    console.log(props.data2);
    (props.data2).map((ele)=>{newList.push(ele)})
    // console.log(newList,"list");
    // if(newList!=[]){    
    setGraphDetails(newList)
    // }
  },[])  //props.data2 used on dependency array

  return (  
    <View style={{marginLeft:"5%",marginTop:"4%"}}>
    <LineChart
      data={
        {
          labels: ["9","10","11","12","1","2"],
          datasets: [
              {
                data: grahDetail,
              },
            ],
          }
      }
      width={350}
      height={290}
      yAxisLabel=""
      chartConfig={{
        backgroundColor: '#e26a00',
        backgroundGradientFrom: '#fb8c00',
        backgroundGradientTo: '#008000',
        decimalPlaces: 0,
        color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
        style: {
          borderRadius: 16,        
        },
      }}
      bezier
    />
    </View>
  );
} 


