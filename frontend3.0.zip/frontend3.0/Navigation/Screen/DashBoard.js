import * as React from "react";
import { View, Text,Alert } from "react-native";
import { useState, useEffect } from "react";
import { MonthlyChargeTimeGraph } from "./Graph";
import { ValueData } from "./ValueData";
import { GetBatteryData } from "../Services/Api";
import { Button} from 'react-native';
import * as Notifications from 'expo-notifications';
export default function DashBoard({ navigation }) {
  const [data, setData] = useState(0.0);
  const [Error, setError] = useState("");
  const [temperature, setTemperature] = useState(28);
  const [voltage, setVoltage] = useState(12.5);
  const [current, setCurrent] = useState(3);
  const [graphdata,setGraphData]=useState([100, 100, 100, 96, 90, 85] ); //default data for graph
  useEffect(() => {
    askForNotificationPermission();
    getSOH()
      .then((data) => {
        // console.log("data", data);
        setData(data.healthState);
      })
      .catch((err) => console.error("err", err));
    getDataDetails()
    // if(data<80){
    //   showPopUpNotification()
    //   sendNotification()
    // }
    // if(data<80){
    //   sendNotification()
    // }
    // getDataDetails()
},[]);

  // useEffect(()=>{
  //   // if(data<=68){
  //   //   sendNotification()
  //   // }
  // })
  const askForNotificationPermission = async () => {
    const { status } = await Notifications.requestPermissionsAsync();
    if (status !== 'granted') {
      alert('Permission to send notifications was denied!');
    }
  };
  const showPopUpNotification = () => {
    Alert.alert('Alert!', 'Battery Life is Below Than Expected, Please Check Your Battery!!');
  };
  const sendNotification = () => {
    Notifications.scheduleNotificationAsync({
      content: {
        title: 'Notification Title',
        body: 'This is a notification message!',
        data: { someData: 'optional data' }, // You can add optional data here
      },
      trigger: 0.2, // send immediately
    });
  };
  
  function getDataDetails(){
    fetch("https://92fb-2401-4900-633c-5bdb-f14a-da20-5382-46c0.ngrok-free.app/graph")
  .then(response => {
    // Check if the response is successful
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    // Parse the JSON data
    return response.json();
  })
  .then(data => {
    // Handle the JSON data
    hourData=data["hourData"]
    graphData=data["graphData"]
    data4=[]
    // dat3=[1,2,3]
    graphData=graphData.map((ele)=>{data4.push(Math.ceil(ele))})
    hourData = hourData.map(String)
    graphData = graphData.map(String)
    console.log(data4);
    const gh={
      data:data4
    }
    
    setGraphData(data4)
  })
  .catch(error => {
    // Handle any errors
    console.error('There was a problem with your fetch operation:', error);
  });
  }

  async function getSOH() {
    let reqBody = {
      voltage: 3.90652442,
      current: -0.100087203
    };

    // console.log("body input", reqBody);
    // return reqBody;
    try {
      const response = await fetch("https://92fb-2401-4900-633c-5bdb-f14a-da20-5382-46c0.ngrok-free.app/predict", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(reqBody), 
      });
      // console.log(response)
      if (!response.ok) {
        throw Error("request failed");
      }
      const result = await response.json();
      console.log(result);
      return result;
    } catch (error) {
      setError(error.message,"noorerr");
      return error;
    }
  }

  return (
    <View>
      <Text
        style={{
          textAlign: "center",
          marginTop: "3%",
          fontSize: 24,
          fontWeight: 900,
        }}
      >
        Battery
      </Text>
      <Text
        style={{
          marginLeft: "8%",
          marginTop: "8%",
          fontSize: 16,
          fontWeight: 600,
        }}
      >
        State Of Health
      </Text>
      <Text
        style={{
          marginLeft: "8%",
          marginTop: "1%",
          fontSize: 36,
          fontWeight: 600,
        }}
      >
        {data}%
      </Text>

      <Text
        style={{
          marginLeft: "8%",
          marginTop: "1%",
          fontSize: 16,
          fontWeight: 600,
        }}
      >
        Status:
        <Text
          style={{
            color: data > 70 ? "#008000" : data > 50 ? "#FFFF00" : "#FF0000",
            fontSize: 20,
            fontWeight: 600,
          }}
        >
          {" "}
          {data > 70 ? "Good" : data > 50 ? "Warning" : "Danger"}{" "}
        </Text>
      </Text>
      
      <MonthlyChargeTimeGraph data2={graphdata} />
      <ValueData
        voltage={voltage}
        current={current}
        temperature={temperature}
      />
      
    </View>
  );
}
